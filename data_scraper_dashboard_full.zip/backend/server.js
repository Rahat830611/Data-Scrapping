
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();
const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST, port: process.env.DB_PORT, dialect: 'mysql'
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/', (req,res)=>res.send('Backend Running'));

const PORT = process.env.PORT || 5000;
(async ()=>{
  try{ await sequelize.authenticate(); console.log('DB Connected'); app.listen(PORT,()=>console.log('Server on',PORT)); }
  catch(err){ console.error('DB connection failed',err); }
})();
